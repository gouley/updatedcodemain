import nmap
import socket
import ipaddress

def get_local_network():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
    except:
        local_ip = "192.168.43.1"
    finally:
        s.close()

    network = ipaddress.ip_network(local_ip + "/24", strict=False)
    return str(network), local_ip

def scan_network():
    network, local_ip = get_local_network()

    nm = nmap.PortScanner()
    try:
        nm.scan(hosts=network, arguments='-sn')  # Ping scan simple
    except Exception as e:
        print("Erreur scan:", e)
        return []

    devices = []

    for host in nm.all_hosts():
        devices.append({
            "ip": host,
            "hostname": nm[host].hostname() if nm[host].hostname() else host,
            "mac": nm[host]["addresses"].get("mac","Unknown") if "addresses" in nm[host] else "Unknown",
            "vendor": "Unknown",
        })

    # Ajouter le PC local si non détecté
    if local_ip and not any(d["ip"] == local_ip for d in devices):
        devices.append({
            "ip": local_ip,
            "hostname": socket.gethostname(),
            "mac": "Local",
            "vendor": "This PC"
        })

    return devices