from flask import Flask, render_template
from flask_socketio import SocketIO
import time
from scanner import scan_network

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")

known_devices = set()

@app.route("/")
def index():
    return render_template("index.html")

def background_scan():
    global known_devices
    while True:
        try:
            devices = scan_network()
            new_devices = [d for d in devices if d["ip"] not in known_devices]

            for d in new_devices:
                known_devices.add(d["ip"])

            socketio.emit("scan_results", devices)
            if new_devices:
                socketio.emit("new_device", new_devices)

        except Exception as e:
            print("Erreur scan:", e)

        time.sleep(10)

@socketio.on("connect")
def connect():
    print("Client connecté")
    socketio.start_background_task(background_scan)

if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=5000, debug=True)