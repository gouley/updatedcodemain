/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.raphael.grc;

import java.util.Date;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author raphael1.coelho
 */
public class SemisTest {
    
    public SemisTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getDateSemis method, of class Semis.
     */
    @Test
    public void testGetDateSemis() {
        System.out.println("getDateSemis");
        Semis instance = null;
        Date expResult = null;
        Date result = instance.getDateSemis();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDateSemis method, of class Semis.
     */
    @Test
    public void testSetDateSemis() {
        System.out.println("setDateSemis");
        Date dateSemis = null;
        Semis instance = null;
        instance.setDateSemis(dateSemis);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSurfaceSemeeHa method, of class Semis.
     */
    @Test
    public void testGetSurfaceSemeeHa() {
        System.out.println("getSurfaceSemeeHa");
        Semis instance = null;
        float expResult = 0.0F;
        float result = instance.getSurfaceSemeeHa();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setSurfaceSemeeHa method, of class Semis.
     */
    @Test
    public void testSetSurfaceSemeeHa() {
        System.out.println("setSurfaceSemeeHa");
        float surfaceSemeeHa = 0.0F;
        Semis instance = null;
        instance.setSurfaceSemeeHa(surfaceSemeeHa);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getQteRecolteParUnite method, of class Semis.
     */
    @Test
    public void testGetQteRecolteParUnite() {
        System.out.println("getQteRecolteParUnite");
        Semis instance = null;
        float expResult = 0.0F;
        float result = instance.getQteRecolteParUnite();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setQteRecolteParUnite method, of class Semis.
     */
    @Test
    public void testSetQteRecolteParUnite() {
        System.out.println("setQteRecolteParUnite");
        float qteRecolteParUnite = 0.0F;
        Semis instance = null;
        instance.setQteRecolteParUnite(qteRecolteParUnite);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getUniteRecolte method, of class Semis.
     */
    @Test
    public void testGetUniteRecolte() {
        System.out.println("getUniteRecolte");
        Semis instance = null;
        String expResult = "";
        String result = instance.getUniteRecolte();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setUniteRecolte method, of class Semis.
     */
    @Test
    public void testSetUniteRecolte() {
        System.out.println("setUniteRecolte");
        String uniteRecolte = "";
        Semis instance = null;
        instance.setUniteRecolte(uniteRecolte);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Semis.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Semis instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getnom method, of class Semis.
     */
    @Test
    public void testGetnom() {
        System.out.println("getnom");
        Semis instance = null;
        Culture expResult = null;
        Culture result = instance.getnom();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setNom method, of class Semis.
     */
    @Test
    public void testSetNom() {
        System.out.println("setNom");
        Culture uneCulture = null;
        Semis instance = null;
        instance.setNom(uneCulture);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
