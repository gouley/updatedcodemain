/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.raphael.grc;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author raphael1.coelho
 */
public class ParcelleTest {
    
    public ParcelleTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getNoCadastralEtendu method, of class Parcelle.
     */
    @Test
    public void testGetNoCadastralEtendu() {
        System.out.println("getNoCadastralEtendu");
        Parcelle instance = null;
        int expResult = 0;
        int result = instance.getNoCadastralEtendu();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setNoCadastralEtendu method, of class Parcelle.
     */
    @Test
    public void testSetNoCadastralEtendu() {
        System.out.println("setNoCadastralEtendu");
        int noCadastralEtendu = 0;
        Parcelle instance = null;
        instance.setNoCadastralEtendu(noCadastralEtendu);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSurfaceParcelleHa method, of class Parcelle.
     */
    @Test
    public void testGetSurfaceParcelleHa() {
        System.out.println("getSurfaceParcelleHa");
        Parcelle instance = null;
        float expResult = 0.0F;
        float result = instance.getSurfaceParcelleHa();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setSurfaceParcelleHa method, of class Parcelle.
     */
    @Test
    public void testSetSurfaceParcelleHa() {
        System.out.println("setSurfaceParcelleHa");
        float surfaceParcelleHa = 0.0F;
        Parcelle instance = null;
        instance.setSurfaceParcelleHa(surfaceParcelleHa);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSurfaceClasseHa method, of class Parcelle.
     */
    @Test
    public void testGetSurfaceClasseHa() {
        System.out.println("getSurfaceClasseHa");
        Parcelle instance = null;
        float expResult = 0.0F;
        float result = instance.getSurfaceClasseHa();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setSurfaceClasseHa method, of class Parcelle.
     */
    @Test
    public void testSetSurfaceClasseHa() {
        System.out.println("setSurfaceClasseHa");
        float surfaceClasseHa = 0.0F;
        Parcelle instance = null;
        instance.setSurfaceClasseHa(surfaceClasseHa);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCommune method, of class Parcelle.
     */
    @Test
    public void testGetCommune() {
        System.out.println("getCommune");
        Parcelle instance = null;
        Commune expResult = null;
        Commune result = instance.getCommune();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setCommune method, of class Parcelle.
     */
    @Test
    public void testSetCommune() {
        System.out.println("setCommune");
        Commune commune = null;
        Parcelle instance = null;
        instance.setCommune(commune);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Parcelle.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Parcelle instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
