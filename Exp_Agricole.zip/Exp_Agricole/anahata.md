# Anahata Project Notes

This file is for Anahata AI Assistant's notes regarding the 'Exp_Agricole' project.
