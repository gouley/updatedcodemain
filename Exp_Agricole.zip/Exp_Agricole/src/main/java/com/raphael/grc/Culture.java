/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raphael.grc;

/**
 *
 * @author raphael1.coelho
 */
public class Culture {
    
    private String nom;
    
    public Culture (String nom) { 
        this.nom = nom;
    }
    public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}
        
        @Override
	public String toString() {
		return "Culture [nom=" + nom + " ]";
	}
}
