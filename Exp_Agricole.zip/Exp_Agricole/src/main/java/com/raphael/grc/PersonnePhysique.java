/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raphael.grc;
import java.time.LocalDate;
/**
 *
 * @author raphael1.coelho
 */public class PersonnePhysique extends Tiers {
    private String prenom;
    private LocalDate dateNaissance;

    public PersonnePhysique(String nom, String adresse) {
        this(nom, adresse, null, null);
    }

    public PersonnePhysique(String nom, String adresse, String prenom, LocalDate dateNaissance) {
        super(nom, adresse);
        this.dateNaissance = dateNaissance;
        this.prenom = prenom;   
    }
    
    public String getPrenom(){
         return this.prenom;
     }
     
     public void setPrenom(String prenom){
         this.prenom = prenom;
     }

    public void setPreom(String prenom) {
        setPrenom(prenom);
    }
     
     public LocalDate getDateNaissance(){
         return this.dateNaissance;
     }
     
    public void setDateNaissance(LocalDate dateNaissance) {
        this.dateNaissance = dateNaissance;
    }
     
    public String toString(){
        return super.toString() + this.prenom + this.dateNaissance;
    }
     
}
