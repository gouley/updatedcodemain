/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raphael.grc;
import java.time.LocalDate;
/**
 *
 * @author raphael1.coelho
 */
public class GAEC extends Exploitation {

    private int dureeEnAnnee;
    private float capital;

    public GAEC(String nom, String adresse,
                int noExploitation, LocalDate dateDebut,
            int dureeEnAnnee, float capital,
            PersonnePhysique leResponsable) {

        super(nom, adresse, noExploitation, dateDebut, leResponsable);

        this.dureeEnAnnee = dureeEnAnnee;
        this.capital = capital;
    }

    public int getDureeEnAnnee() {
        return dureeEnAnnee;
    }

    public void setDureeEnAnnee(int dureeEnAnnee) {
        this.dureeEnAnnee = dureeEnAnnee;
    }

    public float getCapital() {
        return capital;
    }

    public void setCapital(float capital) {
        this.capital = capital;
    }


    @Override
    public String toString() {
        return "GAEC{" +
                super.toString()+
                ", dureeEnAnnee=" + dureeEnAnnee +
                ", capital=" + capital +
                '}';
    }
}