/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raphael.grc;

/**
 *
 * @author raphael1.coelho
 */
public class Associe extends PersonnePhysique {
 
  private  int nbParts;
   
    public Associe(String nom, String adresse, int nbParts) {
        super(nom, adresse);
        this.nbParts= nbParts;
    }   
    
}
