/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raphael.grc;
/**
 *
 * @author raphael1.coelho
 */
public class PersonneMorale extends Tiers {
    
    public PersonneMorale (String nom, String adresse) {
        super(nom,adresse);
    }

}
