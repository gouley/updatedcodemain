package com.raphael.grc;

public class Parcelle {
	private int noCadastralEtendu;
	private float surfaceParcelleHa;
	private float surfaceClasseHa;
	private Commune commune;
	
	public Parcelle(int noCadastralEtendu, float surfaceParcelleHa,
			float surfaceClasseHa, Commune commune) {
		this.noCadastralEtendu = noCadastralEtendu;
		this.surfaceParcelleHa = surfaceParcelleHa;
		this.surfaceClasseHa = surfaceClasseHa;
		this.commune = commune;
	}

	public int getNoCadastralEtendu() {
		return noCadastralEtendu;
	}

	public void setNoCadastralEtendu(int noCadastralEtendu) {
		this.noCadastralEtendu = noCadastralEtendu;
	}

	public float getSurfaceParcelleHa() {
		return surfaceParcelleHa;
	}

	public void setSurfaceParcelleHa(float surfaceParcelleHa) {
		this.surfaceParcelleHa = surfaceParcelleHa;
	}

	public float getSurfaceClasseHa() {
		return surfaceClasseHa;
	}

	public void setSurfaceClasseHa(float surfaceClasseHa) {
		this.surfaceClasseHa = surfaceClasseHa;
	}

	public Commune getCommune() {
		return commune;
	}

	public void setCommune(Commune commune) {
		this.commune = commune;
	}

	@Override
	public String toString() {
		return "Parcelle [noCadastralEtendu=" + noCadastralEtendu
				+ ", surfaceParcelleHa=" + surfaceParcelleHa
				+ ", surfaceClasseHa=" + surfaceClasseHa
				+ ", commune=" + commune + "]";
	}
	
}
