/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.raphael.grc;

/**
 *
 * @author raphael1.coelho
 */
public class Exp_Agricole {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
