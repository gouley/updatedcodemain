/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.raphael.grc;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author raphael1.coelho
 */
public class CommuneTest {

    private Commune instance;

    public CommuneTest() {
    }

    @BeforeAll
    public static void setUpClass() {
    }

    @AfterAll
    public static void tearDownClass() {
    }

    @BeforeEach
    public void setUp() {
        instance = new Commune("Azay", "37190");
    }

    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testConstructeurAccesseursEtToString() {
        assertEquals("Azay", instance.getNom());
        assertEquals("37190", instance.getCodePostal());
        assertEquals("Commune [nom=Azay, codePostal=37190]", instance.toString());

        instance.setNom("Tours");
        instance.setCodePostal("37000");

        assertEquals("Tours", instance.getNom());
        assertEquals("37000", instance.getCodePostal());
    }
}