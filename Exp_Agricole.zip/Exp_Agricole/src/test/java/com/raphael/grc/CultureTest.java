/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.raphael.grc;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author raphael1.coelho
 */
public class CultureTest {

    private Culture instance;

    public CultureTest() {
    }

    @BeforeAll
    public static void setUpClass() {
    }

    @AfterAll
    public static void tearDownClass() {
    }

    @BeforeEach
    public void setUp() {
        instance = new Culture("blé");
    }

    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testGetNom() {
        String expResult = "blé";
        String result = instance.getNom();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetNom() {
        String nom = "orge";
        instance.setNom(nom);
        assertEquals(nom, instance.getNom());
    }

    @Test
    public void testToString() {
        String expResult = "Culture [nom=blé ]";
        String result = instance.toString();
        assertEquals(expResult, result);
    }
}
