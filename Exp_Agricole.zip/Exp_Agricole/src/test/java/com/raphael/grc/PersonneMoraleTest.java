/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.raphael.grc;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author raphael1.coelho
 */
public class PersonneMoraleTest {

    private PersonneMorale instance;

    public PersonneMoraleTest() {
    }

    @BeforeAll
    public static void setUpClass() {
    }

    @AfterAll
    public static void tearDownClass() {
    }

    @BeforeEach
    public void setUp() {
        instance = new PersonneMorale("Chris", "Boulogne");
    }

    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testHeriteDeTiers() {
        assertEquals("Chris", instance.getNom());
        assertEquals("Boulogne", instance.getAdresse());
    }
}
