/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.raphael.grc;

import java.time.LocalDate;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author raphael1.coelho
 */
public class GAECTest {

    private GAEC instance;

    public GAECTest() {
    }

    @BeforeAll
    public static void setUpClass() {
    }

    @AfterAll
    public static void tearDownClass() {
    }

    @BeforeEach
    public void setUp() {
        instance = new GAEC("GAEC des Prés", "Azay", 7,
            LocalDate.of(2020, 3, 1), 9, 12500.50f,
            new PersonnePhysique("Martin", "Azay"));
    }

    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testGereLaDureeLeCapitalEtLeNombreDePartsInitial() {

        assertEquals(9, instance.getDureeEnAnnee());
        assertEquals(12500.50f, instance.getCapital());

        instance.setDureeEnAnnee(10);
        instance.setCapital(15000f);

        assertEquals(10, instance.getDureeEnAnnee());
        assertEquals(15000f, instance.getCapital());
        assertTrue(instance.toString().contains("dureeEnAnnee=10"));
        assertTrue(instance.toString().contains("capital=15000.0"));
    }
}