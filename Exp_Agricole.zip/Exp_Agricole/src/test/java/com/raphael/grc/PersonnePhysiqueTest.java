/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.raphael.grc;

import java.time.LocalDate;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author raphael1.coelho
 */
public class PersonnePhysiqueTest {

    private PersonnePhysique instance;

    public PersonnePhysiqueTest() {
    }

    @BeforeAll
    public static void setUpClass() {
    }

    @AfterAll
    public static void tearDownClass() {
    }

    @BeforeEach
    public void setUp() {
        LocalDate date = LocalDate.of(1990, 5, 12);
        instance = new PersonnePhysique("Alice", "Tours", "Jean", date);
    }

    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testGereLePrenomEtLaDateDeNaissance() {
        LocalDate date = LocalDate.of(1990, 5, 12);

        instance.setPrenom("Alice");
        instance.setDateNaissance(date);

        assertEquals("Alice", instance.getPrenom());
        assertEquals(date, instance.getDateNaissance());
    }
}