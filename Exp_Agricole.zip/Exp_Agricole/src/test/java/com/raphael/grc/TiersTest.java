/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.raphael.grc;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author raphael1.coelho
 */
public class TiersTest {

    private Tiers instance;

    public TiersTest() {
    }

    @BeforeAll
    public static void setUpClass() {
    }

    @AfterAll
    public static void tearDownClass() {
    }

    @BeforeEach
    public void setUp() {
        instance = new Tiers("Raphael", "Azay");
    }

    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testConstructeurEtAccesseurs() {

        assertEquals("Raphael", instance.getNom());
        assertEquals("Azay", instance.getAdresse());

        instance.setNom("Josianne");
        instance.setAdresse("Tours");

        assertEquals("Josianne", instance.getNom());
        assertEquals("Tours", instance.getAdresse());
    }

    @Test
    public void testToStringRetourneSesInformations() {
        assertEquals("Tiers [nom=Raphael, adresse=Azay, commune=Commune [nom=Tours, codePostal=37000]]",
            instance.toString());
    }
}
